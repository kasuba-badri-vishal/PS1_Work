# PS1_Work
Internship work done at Parinati Solutions, Goa
